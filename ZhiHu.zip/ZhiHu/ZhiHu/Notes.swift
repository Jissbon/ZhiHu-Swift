//
//  Notes.swift
//  ZhiHu
//
//  Created by zx on 16/1/6.
//  Copyright © 2016年 zx. All rights reserved.
//

import Foundation

//Alamofire网络库 http://www.cocoachina.com/ios/20141202/10390.html
//CocosPods http://www.open-open.com/lib/view/open1435646151482.html

//SwiftyJSON JSON解析

//SDCycleScrollView 循环滚动ScrollView

//ParallaxView 
//myUILabel.h
//UIImage+ImageEffects
//GradientView 颜色梯度 颜色渐变


// 静态图－动态化的工具 JSAnimatedImagesView 。类似“新浪视野
//http://blog.csdn.net/qhexin/article/details/8657643

//（页面切换时的动画）
//ZFModalTransitionAnimator


